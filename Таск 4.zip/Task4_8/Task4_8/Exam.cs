﻿using System;

namespace Task4_8
{
    public class Exam
    {
        private String discipline;
        protected int numberStudents;
        protected double duration;

        public Exam(string discipline, int numberStudents, double duration)
        {
            this.discipline = discipline;
            this.numberStudents = numberStudents;
            this.duration = duration;
        }

        public virtual double Quality()
        {
            return numberStudents / duration;
        }

        public override string ToString()
        {
            return "Экзамен по дисциплине: " + discipline + ". Количество студентов: " + numberStudents +
                   ". Продолжительность: " + duration + "ч. ";
        }
    }
}