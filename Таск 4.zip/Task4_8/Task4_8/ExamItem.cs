﻿using System.Globalization;

namespace Task4_8
{
    public class ExamItem : Exam
    {
        private int percentTwos;

        public ExamItem(string discipline, int numberStudents, double duration, int percentTwos) : base(discipline, numberStudents, duration)
        {
            this.percentTwos = percentTwos;
        }

        public override double Quality()
        {
            return (numberStudents/duration)*(100 - percentTwos)/100;
        }

        public override string ToString()
        {
            return base.ToString() + "Процент двоек: " + percentTwos + "%.";
        }
    }
}