﻿using System;

namespace Task4_8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите дисцилину экзамена: ");
            String discipline = Console.ReadLine();
            Console.WriteLine("Введите число студентов на экзамене: ");
            int numberStudents = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите продолжительность экзамена в часах: ");
            double duration = Convert.ToDouble(Console.ReadLine());
            Exam exam = new Exam(discipline, numberStudents, duration);
            Console.WriteLine("Введите процент двоек: ");
            int percentTwos = Convert.ToInt32(Console.ReadLine());
            ExamItem examItem = new ExamItem(discipline, numberStudents, duration, percentTwos);
            Console.WriteLine(exam);
            Console.WriteLine("Качество экзамена: " + exam.Quality());
            Console.WriteLine(examItem);
            Console.WriteLine("Качество потомка: " + examItem.Quality());
        }
    }
}